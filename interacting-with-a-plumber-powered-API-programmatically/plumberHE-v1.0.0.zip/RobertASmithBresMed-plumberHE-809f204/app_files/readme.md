# App readme

If your project does not require a shiny app then please delete this folder.

The book [Mastering Shiny](https://mastering-shiny.org/) by Hadley Wickham is probably the best go-to resource for Shiny.