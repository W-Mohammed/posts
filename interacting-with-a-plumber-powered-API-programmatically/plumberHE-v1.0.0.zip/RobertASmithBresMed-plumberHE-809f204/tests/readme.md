# AA repository tests

Testing functions is an important part of coding in R. 
For more information on testing using the `testthat package see this online tutorial [here](https://testthat.r-lib.org/). 

Testthat can be used inside or outside of packages.

A single example is provided in the `testthat` folder. 
It can be used by running the `test_code` file.