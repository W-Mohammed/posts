# AA repository folder Outputs

Folder for outputs, these may take the form of model outputs, tables, plots, figures etc.
