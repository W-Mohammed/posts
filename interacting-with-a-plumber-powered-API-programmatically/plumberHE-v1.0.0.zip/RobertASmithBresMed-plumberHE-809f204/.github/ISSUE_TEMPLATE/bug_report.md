---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**If the problem can be restricted to a certain chunk of code then**
1. Click on the number next to a line of the code in GitHub.
2. Insert that link here so the reviewer can see where the problem is.

**If the problem cannot be restricted to a certain chunk then describe how to reproduce the bug**
Steps to reproduce the behavior:
1. Go to '...'
3. Click on '....'
4. Scroll down to '....'
5. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Desktop (please complete the following information):**
 - OS: [e.g. iOS]
 - Browser [e.g. chrome, safari]
 - Version [e.g. 22]

**Additional context**
Add any other context about the problem here.
